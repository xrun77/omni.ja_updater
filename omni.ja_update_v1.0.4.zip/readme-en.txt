@charset="utf-8"
https://translate.google.com

omni.ja_update.exe (x32)

This program allows you to automatically edit the omni.ja file.
Just run the program, edit the created ini file and run it again.
All errors are recorded in the ERROR.log log. Errors in the current section of the ini file are recorded in full with a comment for each, the following sections are skipped. If no errors are found, a file omni_mod.ja will be created next to the program.

https://www.virustotal.com/gui/file/480490bbe84c494a3cffa86a4780915799a408ee79be397a6ea6bc5d7256dcad/detection
There is a lot of detection, perhaps due to the fact that the program contains a Python script compiled into an exe and a dll archiver library, which are unpacked into the %TEMP% folder when the program is launched. These are necessary components for the program to work.

The program has two optional command line launch options:
omni.ja_update.exe [/?|-?|?] [/i|-i|i]
[/?|-?|?] - "About" window
[/i|-i|i] - select an ini file. Default omni.ja_update.ini

About deleting folders and files.
The optimizejars.py script, when deoptimizing omni.ja, creates a certain list file omni.ja.log with files and folders (currently there are 169 lines, version 120.0.1). Optimization uses this file and I don't know how the new omni.ja will work if you deleted a file or folder from this list in the omni.ja file. Therefore, when deleting, the list is checked and if what you want to delete is in this list, this is considered an error. You can cancel the check at your own risk:
CheckPreload=any value other than on
NB: Deleting files is possible using a mask (wildcards). BUT! There must be an expansion. For example, correct:
DeleteFile=chrome\toolkit\skin\classic\global\icons\arrow-????-12.svg
DeleteFile=chrome\toolkit\skin\classic\global\icons\edit*.svg
DeleteFile=\modules\*.jsm
incorrect (file extension - mask):
DeleteFile=\modules\About*.sys.*
You can paste these lines into the omni.ja_update.ini file and try, you will see a list of errors in ERROR.log.

About copying.
Copying to omni.ja is considered to be a file replacement operation. That is, it already exists in the folder where you are copying your file. If the file is not there, it is considered an error. Adding folders is not possible. You can disable the check, and the files will not only be replaced, but also added:
CheckDestination=any value other than on

About editing.
When the program reads the "search" and "replace" values (Find= & Replace=), the spaces on the left are removed. If you need to save them, use the vertical bar symbol immediately after the equal sign "=".

(c) aka xrun1/xrun77